// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "LinkedList",
    products: [.library(name: "LinkedList", targets: ["LinkedList"])],
    targets: [.target(name: "LinkedList")]
)
