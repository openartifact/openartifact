public struct LinkedList { public init() {}; public func hello() -> String { "hello from LinkedList" } }
